from manager.main import main


def entry():
    main()
